# FAQ for PyJNIus

## Introduction

PyJNIus is a [Python](https://www.python.org/) library for accessing 
[Java](https://www.java.com/) classes using the 
[Java Native Interface](https://docs.oracle.com/javase/8/docs/technotes/guides/jni/)
(JNI). 

Warning: the [PyPI](https://pypi.org/) package name is now 
[pyjnius](https://pypi.org/project/pyjnius/) instead of `jnius`.

## No questions yet

No Frequently Asked Questions have been identified yet. Please contribute some.
