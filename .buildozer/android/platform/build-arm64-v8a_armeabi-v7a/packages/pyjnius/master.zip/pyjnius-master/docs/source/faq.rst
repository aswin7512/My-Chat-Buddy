.. _faq:

FAQ
===

PyJNIus has an `online FAQ <https://github.com/kivy/pyjnius/blob/master/FAQ.md>`_. It contains the answers to
questions that repeatedly come up.
