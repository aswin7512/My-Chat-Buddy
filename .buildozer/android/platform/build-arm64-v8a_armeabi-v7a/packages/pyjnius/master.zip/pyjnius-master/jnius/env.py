from jnius_config.env import get_java_setup, JavaLocation, WindowsJavaLocation, BSDJavaLocation, AndroidJavaLocation
from jnius_config.env import get_jre_home, get_jdk_home
# this file is just a shim - env has been moved to jnius_config.env
