.. _contact:

Contact Us
==========

If you are looking to contact us, including looking for support, please see our
`latest contact details <https://github.com/kivy/kivy/blob/master/CONTACT.md>`_.