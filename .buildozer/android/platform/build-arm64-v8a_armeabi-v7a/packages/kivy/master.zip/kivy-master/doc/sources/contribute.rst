.. _contribute:

Contribution Guidelines
=======================

Kivy is a large product used by many thousands of developers for free, but it
is built entirely by the contributions of volunteers. We welcome (and rely on)
users who want to give back to the community by contributing to the project.

Contributions can come in many forms. To learn more, see our
`latest Contribution Guidelines <https://github.com/kivy/kivy/blob/master/CONTRIBUTING.md>`_.