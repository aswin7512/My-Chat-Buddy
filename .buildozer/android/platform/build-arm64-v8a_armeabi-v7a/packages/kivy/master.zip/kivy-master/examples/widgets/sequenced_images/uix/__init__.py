'''
UIX
===

The `uix` contains all the class for creating and arranging Custom Widgets.
A widget is an element of a graphical user interface.
'''
