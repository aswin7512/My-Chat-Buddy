In the interest of fostering an open and welcoming community, we as 
contributors and maintainers need to ensure participation in our project and 
our sister projects is a harassment-free and positive experience for everyone. 
It is vital that all interaction is conducted in a manner conveying respect, 
open-mindedness and gratitude.

We have adopted V2.1 of the 
[Contributor Covenant Code of Conduct](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).
Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported to any of our [core developers](https://kivy.org/about.html) via 
[Discord](https://chat.kivy.org). (You might like to check which have been recently 
active on Discord to get a faster response.)
